
class NoAudioError(Exception):
    pass

